﻿using Hangfire;
using Hangfire1.Job;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Hangfire1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobController : ControllerBase
    {
        [HttpPost]
        [Route("CreateBackgroundJob")]
        public ActionResult CreateBackgroundJob()
        {
            //BackgroundJob.Enqueue(()=> Console.WriteLine("Background Job gets Triggered"));
            BackgroundJob.Enqueue<TestJob>(x => x.WriteLog("Background Job Triggered"));
            return Ok();
        }

        [HttpPost]
        [Route("CreateScheduleJob")]
        public ActionResult CreateScheduleJob()
        {
            var scheduleDateTime = DateTime.UtcNow.AddSeconds(5);
            var dateTimeOffSet = new DateTimeOffset(scheduleDateTime);
            BackgroundJob.Schedule(() => Console.WriteLine("Schedule Job gets Triggered"),dateTimeOffSet);
            return Ok();
        }

        [HttpPost]
        [Route("CreateContinuationJob")]
        public ActionResult CreateContinuationJob()
        {
            var scheduleDateTime = DateTime.UtcNow.AddSeconds(5);
            var dateTimeOffSet = new DateTimeOffset(scheduleDateTime);
            var JobId=BackgroundJob.Schedule(() => Console.WriteLine("Schedule Job gets Triggered"), dateTimeOffSet);

            var Job1Id=BackgroundJob.ContinueJobWith(JobId, () => Console.WriteLine("Continuation Job 1 Trigger"));
            var Job2Id = BackgroundJob.ContinueJobWith(Job1Id, () => Console.WriteLine("Continuation Job 2 Trigger"));
            var Job3Id = BackgroundJob.ContinueJobWith(Job2Id, () => Console.WriteLine("Continuation Job 3 Trigger"));

            return Ok();
        }

        [HttpPost]
        [Route("CreateRecurringJob")]
        public ActionResult CreateRecurringJob()
        {
            RecurringJob.AddOrUpdate("RecurringJob1",() => Console.WriteLine("Background Job gets Triggered"),"* * * * *");
            return Ok();
        }
    }
}
