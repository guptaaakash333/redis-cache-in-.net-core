﻿using Hangfire;
using Hangfire1.Job;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Asn1.Ocsp;

namespace Hangfire1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly EmailService _emailService;

        public EmailController(EmailService emailService)
        {
            _emailService = emailService;
        }

        [HttpPost("send")]
        public IActionResult SendEmail([FromBody] EmailRequest request)
        {
            BackgroundJob.Enqueue(() => _emailService.SendEmail(request.ToEmail, request.Subject, request.Message));
            return Ok("Email is being sent in the background...");
        }

        //[HttpPost("send")]
        //public IActionResult SendEmail([FromBody] EmailRequest request)
        //{
        //    // Schedule a recurring job to send email every minute
        //    RecurringJob.AddOrUpdate(
        //        "send-email-every-minute", // A unique ID for the recurring job
        //        () => _emailService.SendEmail(request.ToEmail, request.Subject, request.Message),
        //        Cron.Minutely); // Cron expression for every minute
        //    return Ok("Recurring job is set to send email every minute.");
        //}

        //[HttpPost("send")]
        //public IActionResult SendEmail([FromBody] EmailRequest request)
        //{
        //    var scheduleDateTime = DateTime.UtcNow.AddMinutes(1);
        //    var dateTimeOffSet = new DateTimeOffset(scheduleDateTime);
        //    BackgroundJob.Schedule(() => _emailService.SendEmail(request.ToEmail, request.Subject, request.Message), dateTimeOffSet);
        //    return Ok();
        //}
    }

}
