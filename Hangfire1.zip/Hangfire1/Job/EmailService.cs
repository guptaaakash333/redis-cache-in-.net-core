﻿using MailKit.Net.Smtp;
using MimeKit;

namespace Hangfire1.Job
{
    public class EmailService
    {
        private readonly IConfiguration _configuration;

        public EmailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void SendEmail(string toEmail, string subject, string message)
        {
            var emailSettings = _configuration.GetSection("EmailSettings");
            var smtpServer = emailSettings["SmtpServer"];
            var smtpPort = int.Parse(emailSettings["SmtpPort"]);
            var smtpUser = emailSettings["SmtpUser"];
            var smtpPass = emailSettings["SmtpPass"];

            var email = new MimeMessage();
            email.From.Add(new MailboxAddress("TCS Confirmation", smtpUser));
            email.To.Add(new MailboxAddress("", toEmail));
            email.Subject = "Congratulations! You Have Been Selected";
            email.Body = new TextPart("plain")
            {
                Text = "Dear ,\r\n\r\nI am pleased to inform you that you have been selected for the [Software Developer] role at [TCS]. We were impressed with your skills and qualifications and are excited to have you join our team.\r\n\r\nPlease let us know a suitable time for you to come in and discuss the next steps.\r\n\r\nCongratulations again, and we look forward to working with you!\r\n\r\nBest regards,\r\n[Talent Acqusation Team(TCS)]"
            };
            using var smtp = new SmtpClient();
            smtp.Connect(smtpServer, smtpPort, MailKit.Security.SecureSocketOptions.StartTls);
            smtp.Authenticate(smtpUser, smtpPass);
            smtp.Send(email);
            smtp.Disconnect(true);
        }
    }
}
