﻿namespace Hangfire1.Job
{
    public class User
    {
    }
}
