﻿namespace Hangfire1.Job
{
    public class TestJob
    {
        private readonly ILogger _logger;

        public TestJob(ILogger<TestJob> logger)
        {
            _logger = logger;
        }

        public void WriteLog(string logmessage) 
        {
            _logger.LogInformation($"{DateTime.Now:yyyy-MM-dd hh:mm:ss tt}{logmessage}");
        }
    }
}
