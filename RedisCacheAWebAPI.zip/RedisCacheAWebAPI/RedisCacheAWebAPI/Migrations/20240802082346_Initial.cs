﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RedisCacheAWebAPI.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Persons",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Persons", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Persons",
                columns: new[] { "Id", "Address", "City", "DateOfBirth", "Email", "FirstName", "Gender", "LastName", "PhoneNumber", "State" },
                values: new object[,]
                {
                    { new Guid("01df88ec-8afc-4cf9-b5c5-d956290af10a"), "59909 Hogan Rapid", "Susanmouth", new DateTime(1962, 9, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), "joshuacain@jefferson.com", "David", "Female", "Ryan", "001-645-052-2694", "Delaware" },
                    { new Guid("0367d414-5364-4fe6-afd9-0c6f91b16f67"), "31858 Bryan Divide Suite 676", "West Marioburgh", new DateTime(1952, 4, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), "thompsonmichelle@sharp.net", "Tammy", "Male", "Shaw", "468.732.9098", "Oklahoma" },
                    { new Guid("0d5cb2fb-cad3-4633-bdbe-42cb0313936b"), "78162 Johnson Plains", "Boydland", new DateTime(1952, 3, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "ldavis@gmail.com", "Aaron", "Male", "Johnson", "001-385-501-3281", "Colorado" },
                    { new Guid("0f3b0dec-598c-4304-9c83-d0ce3e776bfe"), "292 Stephenson Ferry Suite 153", "West Jonathan", new DateTime(1985, 3, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), "pamela84@york.com", "Bonnie", "Female", "Sanchez", "(925)270-7789x42784", "Mississippi" },
                    { new Guid("105f4042-66c2-4946-8e8a-2e42c3460e3e"), "27882 Matthews Point Suite 687", "Amandaborough", new DateTime(1975, 2, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), "michael16@yahoo.com", "Kyle", "Female", "Avila", "(771)951-0376", "Colorado" },
                    { new Guid("165c8e81-829a-47f9-8628-46bad0670a06"), "26688 Michael Skyway Suite 486", "Lake Thomas", new DateTime(1947, 1, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), "nmartinez@yahoo.com", "Mariah", "Female", "Callahan", "+1-188-385-2827x706", "Texas" },
                    { new Guid("1884f05b-a9db-4b59-a0db-656272567ff6"), "19694 Mullins Shore Apt. 736", "Kerryshire", new DateTime(1996, 7, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), "mwyatt@yahoo.com", "Ryan", "Female", "Mcdonald", "+1-248-544-9000x573", "Pennsylvania" },
                    { new Guid("1df5a878-7827-491c-b9f9-0b15080646b9"), "23514 Kimberly Parkway Apt. 895", "Davidborough", new DateTime(1980, 7, 24, 0, 0, 0, 0, DateTimeKind.Unspecified), "aaron93@gmail.com", "Nicole", "Male", "Garcia", "(084)277-5108", "Arizona" },
                    { new Guid("233297f6-3e88-49d4-93e0-d2e98c9e8d81"), "647 Zavala Squares", "South Joshua", new DateTime(1988, 8, 19, 0, 0, 0, 0, DateTimeKind.Unspecified), "jennifer08@hotmail.com", "Alexis", "Male", "Deleon", "154-405-5252x16864", "Virginia" },
                    { new Guid("24ed00f5-68f9-4aed-83a7-6a339acf27ad"), "49658 Willis Knolls Suite 557", "Buchananmouth", new DateTime(1950, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "stephensmakayla@hotmail.com", "Tammy", "Male", "West", "(957)737-7094", "Georgia" },
                    { new Guid("25aff6e0-dfbf-4cc9-b71e-b8f462fc9205"), "84986 Charles Springs Suite 476", "Baldwinside", new DateTime(1989, 9, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "ygreen@hotmail.com", "Brianna", "Male", "Bell", "189.483.8652x1922", "Maryland" },
                    { new Guid("270c2f7e-db00-4538-bff7-1ebd5d663cf5"), "385 Russell Greens", "Port Patricia", new DateTime(1948, 6, 26, 0, 0, 0, 0, DateTimeKind.Unspecified), "hallalexis@hotmail.com", "Jennifer", "Male", "Roth", "685.272.8526", "Mississippi" },
                    { new Guid("2c7dc81d-2193-4124-a4ed-6631f4870930"), "6232 Erika Tunnel Apt. 390", "New Katelyn", new DateTime(1960, 12, 26, 0, 0, 0, 0, DateTimeKind.Unspecified), "jeffrey87@rodriguez.com", "Donald", "Female", "Ramirez", "135.501.9190", "Oregon" },
                    { new Guid("303e748a-c2d5-40bb-9de8-988bf0e94c5b"), "03833 Kari Crescent Suite 702", "Thomasfort", new DateTime(1948, 4, 16, 0, 0, 0, 0, DateTimeKind.Unspecified), "jwilliams@jones-johnson.biz", "Kari", "Male", "Alvarado", "+1-583-017-7687x519", "Massachusetts" },
                    { new Guid("30cc6b2f-a43c-46c3-bc10-345f90cf08fc"), "5555 Robin Light", "Laurahaven", new DateTime(2000, 7, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "nicholesmith@yahoo.com", "Valerie", "Female", "Gordon", "(322)194-2078x54250", "West Virginia" },
                    { new Guid("31b1c8fb-426d-4454-8565-83b39a0e0f30"), "423 Johnson Turnpike Suite 090", "Port Matthew", new DateTime(1953, 3, 16, 0, 0, 0, 0, DateTimeKind.Unspecified), "christian40@yahoo.com", "Jorge", "Female", "Sullivan", "(646)533-7427", "Georgia" },
                    { new Guid("327a2979-67f6-49c8-8c0d-d307809d3014"), "2011 Deborah Centers", "Port Courtney", new DateTime(1957, 10, 7, 0, 0, 0, 0, DateTimeKind.Unspecified), "maria04@vincent.net", "Jessica", "Female", "Kaiser", "021.862.7295x2642", "Oklahoma" },
                    { new Guid("34f390aa-3e1d-49c8-845f-1ec0e89c5da5"), "30198 Garcia Flats", "Deniseborough", new DateTime(1951, 2, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "bakerjessica@hotmail.com", "Mary", "Female", "Hooper", "(363)198-9043", "New York" },
                    { new Guid("3f438e85-432a-42a5-9e7a-74bc130f9101"), "562 Christopher Throughway Apt. 547", "Payneville", new DateTime(2001, 12, 6, 0, 0, 0, 0, DateTimeKind.Unspecified), "amystevens@hotmail.com", "Matthew", "Female", "Rivers", "300.357.8502x7036", "Vermont" },
                    { new Guid("448645ca-338a-42dd-b241-ba92482a48a8"), "352 Jensen Forges Suite 787", "Debbieburgh", new DateTime(1982, 10, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), "edonovan@yahoo.com", "Kayla", "Female", "Wade", "(265)812-9500x67303", "South Carolina" },
                    { new Guid("45930f88-b64c-445b-a1c5-114902fc9755"), "413 Guzman Shores", "New Monica", new DateTime(2005, 5, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "charleswillis@scott.com", "Marcus", "Male", "Schmidt", "079-173-4705", "Louisiana" },
                    { new Guid("46a5af3d-e786-456f-a9a4-3bc9a560b209"), "662 Newton Crescent Suite 715", "Lake Gloriachester", new DateTime(2001, 10, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), "barbara79@hotmail.com", "Aaron", "Male", "Perry", "(501)024-0295", "Indiana" },
                    { new Guid("4bfd957c-f861-46c2-a331-9c904ea39780"), "726 Grimes Island", "South Jennafort", new DateTime(1971, 10, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "steven20@yahoo.com", "Jasmine", "Male", "Warren", "128.837.1412x807", "Delaware" },
                    { new Guid("4c267731-902f-4e46-b8e1-7f023991108c"), "639 Taylor Well Suite 959", "Lake Blakemouth", new DateTime(1948, 8, 26, 0, 0, 0, 0, DateTimeKind.Unspecified), "jessica71@walton.net", "Amber", "Male", "Ruiz", "949.746.5505", "West Virginia" },
                    { new Guid("4fc94935-e4d9-4ac8-9e76-11841d13a892"), "5405 Jones Junctions Suite 679", "South Kevinville", new DateTime(1975, 11, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "brianna61@hotmail.com", "Tyler", "Male", "Mcdonald", "588-009-0384x5610", "South Dakota" },
                    { new Guid("50aa2d8a-e434-4a8a-ae27-5312b897aca7"), "249 Peter Overpass Suite 968", "East Meganstad", new DateTime(1985, 3, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), "barnestammy@cantrell-howe.com", "Heather", "Female", "Evans", "(948)881-8718x5729", "South Dakota" },
                    { new Guid("54c5afc2-56ec-4f2a-b89d-02ee1adfc0d3"), "90900 Mcguire Hollow", "Josephburgh", new DateTime(1996, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "eric78@hotmail.com", "Mary", "Female", "Campbell", "001-648-901-8427x65207", "New Mexico" },
                    { new Guid("57ac5001-9b4d-4637-befd-10811523558a"), "749 Martin Courts", "Port Alexandraborough", new DateTime(1976, 12, 7, 0, 0, 0, 0, DateTimeKind.Unspecified), "jerrynguyen@hotmail.com", "Derek", "Male", "Morgan", "001-385-395-7602x972", "Arkansas" },
                    { new Guid("599c6b87-f416-4f36-afd2-7d8a5857893b"), "15744 Samantha Stream Suite 948", "Lynnchester", new DateTime(1974, 12, 29, 0, 0, 0, 0, DateTimeKind.Unspecified), "lindaparsons@hotmail.com", "Gregory", "Female", "Ellis", "(521)219-1797", "Delaware" },
                    { new Guid("5a9b5465-f3cc-45c9-a77c-48cb93a35c7d"), "4005 Melvin Dale", "Lake Paula", new DateTime(1986, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "robertatkins@gmail.com", "Zachary", "Female", "Joyce", "948-675-7615x252", "Montana" },
                    { new Guid("5d0aa815-d29c-496e-ba00-55af5c1022b9"), "2464 Christy River", "Laneside", new DateTime(1995, 9, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), "hfields@gmail.com", "Brian", "Male", "Wong", "001-401-963-8022x1648", "Illinois" },
                    { new Guid("5d37f344-abe6-4542-a89d-c02073989dcf"), "1673 Becky Views", "South Amandatown", new DateTime(1957, 3, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), "james03@jones.com", "Jesse", "Female", "Yang", "360.208.5168x7172", "Indiana" },
                    { new Guid("5e104418-6c69-4b0a-986b-bb10ecc61ca5"), "104 Gina Isle Apt. 479", "Lake Barbara", new DateTime(2004, 8, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "jessicawu@knight.info", "Larry", "Male", "Gilmore", "1904862185", "South Carolina" },
                    { new Guid("5e7e87e4-c28d-4ebf-973f-760132850999"), "303 David Plains", "Port Samuelborough", new DateTime(1961, 4, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), "wallacewilliam@yahoo.com", "Sherry", "Female", "Roberts", "(539)256-6183x450", "Washington" },
                    { new Guid("637f0ad6-eb89-411b-b4a6-f8be30585700"), "7321 Burton Club Apt. 733", "Nelsonshire", new DateTime(1945, 5, 19, 0, 0, 0, 0, DateTimeKind.Unspecified), "jdavid@sullivan-harris.net", "Christopher", "Male", "Miller", "0321968219", "South Dakota" },
                    { new Guid("69c72798-803c-4fe7-b679-1bfb14463040"), "4187 Anthony Spurs Suite 410", "Melissashire", new DateTime(2003, 6, 13, 0, 0, 0, 0, DateTimeKind.Unspecified), "yangkristen@gmail.com", "Linda", "Female", "Brown", "(117)646-2920x48845", "Alaska" },
                    { new Guid("6b4e6871-7b36-443d-b7ed-6b9fe4cd30b0"), "590 Dustin Forges Apt. 411", "South Stephaniestad", new DateTime(1951, 11, 29, 0, 0, 0, 0, DateTimeKind.Unspecified), "fwalker@miller.com", "Tiffany", "Female", "Thompson", "914-764-0195", "Maryland" },
                    { new Guid("6dfac3f0-c272-466a-bbca-0cfb1b1f67cd"), "5790 James Gateway", "Connieland", new DateTime(1976, 10, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "sean58@williams.biz", "Amanda", "Female", "Fisher", "149-014-1724", "New Jersey" },
                    { new Guid("6e637c42-5a82-40bc-9497-67fb94bf0917"), "27218 Daniels Hollow Suite 137", "Andersonstad", new DateTime(1963, 7, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), "ronald26@gmail.com", "Linda", "Male", "Matthews", "+1-153-483-9615x6272", "Pennsylvania" },
                    { new Guid("6e7d8a60-a15d-45fd-a32c-207f023fba8d"), "2203 Mclean Estate", "Johnsonhaven", new DateTime(1989, 10, 27, 0, 0, 0, 0, DateTimeKind.Unspecified), "lucas04@stewart.com", "Margaret", "Female", "Gamble", "(271)945-2466x773", "Utah" },
                    { new Guid("749145e2-2f85-4e15-8eac-197c92033be6"), "9835 Gutierrez Skyway Apt. 250", "Parkershire", new DateTime(1983, 1, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), "austin42@yahoo.com", "Danielle", "Male", "Smith", "885-635-8768x57500", "New York" },
                    { new Guid("75157aa4-357e-4ccf-9394-bfe33d4f328c"), "393 Brenda Station Apt. 477", "North Patriciamouth", new DateTime(1948, 2, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), "mikeobrien@yahoo.com", "Kaitlyn", "Male", "Harris", "0368595173", "New Jersey" },
                    { new Guid("75adcb22-498d-4842-89dc-a78adf2ea385"), "0150 Jay Tunnel Suite 046", "West Isaiah", new DateTime(1955, 5, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "wellsjames@wang.com", "David", "Male", "Morrison", "(358)861-1634x23660", "Connecticut" },
                    { new Guid("7665a3ec-8523-4ec4-b8b4-d9d325df4d2c"), "326 Smith Mission Suite 652", "South Michael", new DateTime(1944, 10, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), "jacobsondawn@yahoo.com", "Jeffery", "Female", "Morgan", "001-030-996-7426", "Nevada" },
                    { new Guid("7a7848d1-245e-4b41-949e-470d3157c227"), "273 Odonnell Spring Apt. 923", "South Ashley", new DateTime(1972, 12, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "zpowell@rojas.biz", "Robert", "Male", "Perry", "001-486-069-6116", "South Dakota" },
                    { new Guid("80360a06-8e0a-421a-9f51-2b7ee4e6c6d2"), "8510 Lindsey Drives", "Port Allenfort", new DateTime(1946, 10, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "courtney24@yahoo.com", "April", "Male", "Pratt", "288.118.9498", "Kentucky" },
                    { new Guid("807a5f92-c073-4641-a939-2633929ea515"), "4333 Garcia Roads", "North Ryan", new DateTime(1980, 9, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), "vbrown@gmail.com", "Leah", "Male", "Schmidt", "633-022-6059x1952", "New Jersey" },
                    { new Guid("84c7f2a4-88b5-4711-98e7-add1c87cc4ab"), "222 Ruth Flat Apt. 978", "Landrytown", new DateTime(1954, 1, 19, 0, 0, 0, 0, DateTimeKind.Unspecified), "david78@gmail.com", "Paul", "Female", "Velasquez", "976-462-4100x2369", "South Dakota" },
                    { new Guid("85dbb497-e649-4697-8ffb-4bef724ff24b"), "291 Kathy Plaza Suite 033", "Reedburgh", new DateTime(1959, 12, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), "kempalice@gomez-mcintosh.com", "Chloe", "Male", "Pennington", "678.072.4744x6280", "Nebraska" },
                    { new Guid("8910f32a-c154-4803-ba17-ce9e480c01bd"), "109 Braun Plain Apt. 183", "Paulafort", new DateTime(1972, 2, 29, 0, 0, 0, 0, DateTimeKind.Unspecified), "dianecook@yahoo.com", "Pamela", "Male", "Baker", "+1-311-291-3430x34515", "New Hampshire" },
                    { new Guid("8a485356-b1dd-48fe-b5f8-c31b97accdd7"), "003 Jessica Mountain", "Jacksonbury", new DateTime(1963, 8, 26, 0, 0, 0, 0, DateTimeKind.Unspecified), "albertwells@davila-cruz.com", "Rachel", "Male", "Ballard", "141.208.1864", "Connecticut" },
                    { new Guid("8b681981-ff6d-4ab7-9ca4-600eb2d7b7bd"), "68167 Lewis Mills Suite 285", "Port Thomas", new DateTime(1965, 9, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "bondtammy@hotmail.com", "Michael", "Female", "Doyle", "001-649-814-7665x7893", "Alaska" },
                    { new Guid("8bb3c8b8-cc6a-4d38-8328-d09934de4b68"), "4495 Aguilar Plaza Apt. 671", "Juliafurt", new DateTime(1946, 10, 19, 0, 0, 0, 0, DateTimeKind.Unspecified), "cunninghamsergio@wallace.com", "Krystal", "Female", "Watson", "001-165-421-3710", "New Hampshire" },
                    { new Guid("90723468-856a-477e-90ec-dfa3790a1efb"), "183 Kyle Cliff", "West Rachel", new DateTime(1972, 4, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "barreraderek@hotmail.com", "Bonnie", "Female", "Allison", "360-448-3776", "Michigan" },
                    { new Guid("91b6a78b-0d32-4b11-b73e-1616d284fa76"), "8414 Wilson Crossing Apt. 162", "North Daniel", new DateTime(2000, 3, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "paynejames@hotmail.com", "Amanda", "Female", "Franklin", "(578)328-4822", "Arkansas" },
                    { new Guid("935448b6-f249-4823-bd08-d7121c08d37e"), "0547 Campbell Key", "Dustinmouth", new DateTime(1954, 8, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "katherine12@hotmail.com", "George", "Female", "Hernandez", "(436)024-6243", "Indiana" },
                    { new Guid("936d26a9-9c3f-4e07-9736-8031d529d5df"), "4459 Daniel Mews Suite 705", "Hollandport", new DateTime(1983, 8, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "deborah80@gray.info", "Joseph", "Female", "Rowe", "+1-602-722-0805", "Wyoming" },
                    { new Guid("962016e7-318a-4eb4-a787-817f0047ccf3"), "58684 Shelly Course Suite 281", "Theresaview", new DateTime(1961, 8, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), "nathaniel46@gmail.com", "William", "Male", "Cervantes", "5419144786", "Delaware" },
                    { new Guid("98c17f7c-da57-487c-8f43-d2620f2317fe"), "7010 Courtney Cliff", "East Kathyborough", new DateTime(1986, 10, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), "qwilliamson@hotmail.com", "Peggy", "Male", "Howell", "(922)242-7868", "Texas" },
                    { new Guid("9b952fb1-30ad-4f49-a394-574f80a8964e"), "6648 Cox Landing Apt. 021", "Lewisfurt", new DateTime(1969, 6, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "jasmine71@garcia.com", "Kimberly", "Male", "Mccoy", "622-932-9538x14335", "Wyoming" },
                    { new Guid("9e593786-1f3e-43a0-8709-b3e0b8b26d84"), "8927 Christina Landing", "Jamieberg", new DateTime(1972, 2, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "arnoldtimothy@garcia-villegas.com", "Erica", "Male", "Roman", "+1-965-171-5710x5312", "Iowa" },
                    { new Guid("a4bd8c9b-2735-4d3d-a423-67bb4de840af"), "6568 Tonya Path", "West Loriview", new DateTime(1954, 6, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), "kharrington@yahoo.com", "Kenneth", "Female", "Bryant", "594-135-4446x321", "Georgia" },
                    { new Guid("a622fc21-a46b-44b2-97b2-ca690d3a87b0"), "622 Karen Valley Suite 010", "Rogersstad", new DateTime(1952, 3, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), "rwang@hotmail.com", "Shannon", "Male", "Bauer", "(520)894-5615", "New York" },
                    { new Guid("a741d22e-fc9b-4024-b02e-dfb9e2099293"), "20536 Willis Estate", "South Jessica", new DateTime(1999, 8, 13, 0, 0, 0, 0, DateTimeKind.Unspecified), "hamptonzachary@yahoo.com", "Christina", "Male", "Wheeler", "137.247.6403x013", "Colorado" },
                    { new Guid("aace83ce-51e8-48a3-bf72-d4880c2e36b6"), "790 Susan Ville Suite 118", "Lisashire", new DateTime(2001, 5, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "ortizbobby@gmail.com", "Teresa", "Male", "Sloan", "+1-339-165-7404", "Ohio" },
                    { new Guid("aead8804-e8a5-4083-a2ff-9992dccc1617"), "0795 Helen Villages Suite 310", "East Angel", new DateTime(1992, 10, 13, 0, 0, 0, 0, DateTimeKind.Unspecified), "lisamorgan@hotmail.com", "Danielle", "Female", "Martinez", "001-826-295-4168x8387", "Texas" },
                    { new Guid("b04c6d28-9cf3-4ebe-9ff8-afffec59fe9b"), "6515 Martinez Ports", "East Nancyport", new DateTime(1959, 4, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "gregorymarilyn@pratt.com", "Crystal", "Female", "Holland", "+1-812-772-1386x978", "New Jersey" },
                    { new Guid("b0c75652-23c3-4c54-ac18-0284ec5fcf32"), "404 Karen Mountains Apt. 462", "Amandamouth", new DateTime(1957, 9, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "mitchell83@gmail.com", "Harold", "Female", "Ramos", "(861)378-3049x636", "Vermont" },
                    { new Guid("b2b33fca-445b-401d-af9c-eb52c9506ad8"), "47171 Andrew Rest Apt. 659", "East Rebeccaview", new DateTime(1998, 9, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), "lyonssean@haynes.com", "Karen", "Male", "Compton", "338-403-3303", "Connecticut" },
                    { new Guid("b2f6c22b-c112-4ddf-9845-c9d7ece38963"), "2907 Michele Mountains Suite 430", "West Frankbury", new DateTime(1985, 11, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "timothy17@yahoo.com", "Thomas", "Female", "Hurley", "828.209.0639x557", "Utah" },
                    { new Guid("b4934f28-f137-4cb0-bb6e-0993b412d7e1"), "3043 Porter Via Suite 611", "Smithside", new DateTime(1963, 10, 17, 0, 0, 0, 0, DateTimeKind.Unspecified), "molinaevelyn@hotmail.com", "Samantha", "Female", "Lucas", "212-429-6308x0145", "California" },
                    { new Guid("b62685f4-37d2-424f-bc8b-450102859c5a"), "1561 Jennifer Wells Suite 568", "West Michelle", new DateTime(1989, 7, 7, 0, 0, 0, 0, DateTimeKind.Unspecified), "wjames@smith.info", "David", "Female", "Cannon", "+1-514-369-6507x556", "Tennessee" },
                    { new Guid("b83f7b60-6f97-44db-b47b-ec8bace6a556"), "151 Kim Shoals", "Rodriguezbury", new DateTime(1977, 8, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), "anitasoto@hotmail.com", "Denise", "Male", "Roth", "+1-430-752-6325x3762", "Montana" },
                    { new Guid("b87038ea-fe14-4f5e-a7c4-ff6cc98d84fb"), "4894 Johnson Square", "Erikchester", new DateTime(1969, 11, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "leemichael@williams.com", "Darius", "Female", "Collins", "(039)576-0707x708", "North Dakota" },
                    { new Guid("b8b042f8-7d72-4805-8bf2-2df244806191"), "823 Banks Turnpike Apt. 332", "North Rebecca", new DateTime(1975, 6, 29, 0, 0, 0, 0, DateTimeKind.Unspecified), "brendaburns@hotmail.com", "Daniel", "Male", "Todd", "024.482.1016", "Nebraska" },
                    { new Guid("b90e892e-fca5-4eed-b22a-db83b354e2e5"), "83646 Marcus Islands", "Port Sarah", new DateTime(1987, 10, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), "morenopaul@yahoo.com", "Victoria", "Female", "Parker", "+1-542-211-5438x48799", "Mississippi" },
                    { new Guid("bc6ce670-d467-4ab5-b8b0-921b4fa63e90"), "7048 Bryan Terrace Apt. 817", "Blairstad", new DateTime(1950, 1, 28, 0, 0, 0, 0, DateTimeKind.Unspecified), "patriciareed@juarez.com", "Carrie", "Male", "Gutierrez", "(052)356-9219", "Tennessee" },
                    { new Guid("bed32789-fbb5-42c2-b38e-e7954fb1a72d"), "13470 Cannon Union Suite 155", "East Tara", new DateTime(1964, 4, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "sarah71@yahoo.com", "Michele", "Male", "Lopez", "106-586-1449x3740", "Nevada" },
                    { new Guid("bfece725-d9af-4cbb-8109-329d35dbee07"), "7594 Jenkins Light Apt. 804", "Floresmouth", new DateTime(1985, 1, 7, 0, 0, 0, 0, DateTimeKind.Unspecified), "davidperez@perez.com", "Jeffrey", "Female", "Ware", "+1-206-584-1434x0123", "North Dakota" },
                    { new Guid("c03a5250-9369-4ded-a39d-596b2915fe62"), "0799 Taylor Meadow Apt. 488", "Port Angelastad", new DateTime(1976, 6, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), "xpeterson@hodges-jacobs.org", "Ryan", "Female", "Hodge", "(006)402-1120x56979", "Oklahoma" },
                    { new Guid("c7f4bbd0-6c05-4d73-b4a1-c9bb83c208a2"), "229 Logan Corner", "Port Lynnton", new DateTime(1980, 8, 11, 0, 0, 0, 0, DateTimeKind.Unspecified), "kwade@gmail.com", "Lisa", "Female", "Allen", "001-717-276-5360x835", "Delaware" },
                    { new Guid("c9e56826-50e0-4e25-b847-a7eaf85f453b"), "66527 Alfred Key Suite 800", "North Jimmy", new DateTime(1990, 6, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), "caitlin88@yahoo.com", "Ashley", "Male", "Vega", "072.841.7557x995", "Alabama" },
                    { new Guid("cc70bbf0-29ca-49be-8351-828d5b9ad136"), "997 Elijah Points Suite 425", "Marcmouth", new DateTime(1993, 3, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "operkins@randall-kelly.info", "Danielle", "Male", "Cantrell", "001-177-322-6923x90956", "Indiana" },
                    { new Guid("cd3addd8-8bdd-4b6b-92cc-5acaecdd1fc6"), "216 Mccoy Fields", "East Jenna", new DateTime(1962, 3, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "stevepatel@sanders.com", "John", "Female", "Collins", "787.912.4297", "North Dakota" },
                    { new Guid("cde8fafd-fca6-4866-a142-06b7475e1655"), "11881 Melissa Land Apt. 962", "South Frankfurt", new DateTime(1985, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "delgadokendra@yahoo.com", "Elizabeth", "Female", "Jones", "357-487-3237x1027", "Michigan" },
                    { new Guid("ced4fb43-e48b-47c9-9282-9e006ef148ae"), "856 Sabrina Spring", "Lawrencetown", new DateTime(1950, 2, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), "bryanbell@hotmail.com", "Jillian", "Female", "Arnold", "+1-914-829-7670", "California" },
                    { new Guid("d0b0041f-af7f-470e-bb32-3f8a1c3baa75"), "98514 Jennifer Viaduct", "Lake Kyleshire", new DateTime(1943, 8, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "ashleymunoz@banks-hernandez.com", "Diana", "Male", "Wilson", "+1-970-594-9294x61141", "North Dakota" },
                    { new Guid("d206e59e-196d-4bb3-b43b-06c1c8a06ec2"), "2260 Ann Stravenue", "South Charles", new DateTime(2006, 7, 13, 0, 0, 0, 0, DateTimeKind.Unspecified), "nperry@mitchell.info", "Lee", "Female", "Miller", "001-889-869-2540x887", "Vermont" },
                    { new Guid("d435d7ef-430c-4088-bb0a-b957816eee6f"), "523 Bob Ville Suite 767", "West Danaville", new DateTime(1983, 8, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), "andrewbaker@gmail.com", "Jennifer", "Female", "Young", "001-626-542-0634", "Tennessee" },
                    { new Guid("d46aea60-6c5f-4331-a87c-9fca843b599f"), "00658 May Meadow", "Carlosmouth", new DateTime(1955, 12, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), "parkerdawn@hotmail.com", "Tony", "Male", "Spencer", "(699)854-7899x004", "Louisiana" },
                    { new Guid("d53bd668-0a5d-4de8-87fa-778531ae243d"), "6561 Mora Motorway", "West Jameshaven", new DateTime(1968, 8, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "donaldanderson@hotmail.com", "David", "Female", "Fernandez", "281-663-0906", "Vermont" },
                    { new Guid("d769d98e-7eca-43d1-b403-949f01c37908"), "3757 Carrie Walk Apt. 653", "North Daleview", new DateTime(1954, 4, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), "troyreed@hotmail.com", "Bryan", "Female", "Delacruz", "(205)096-2709x85165", "Vermont" },
                    { new Guid("dab29d5b-a54a-43d8-839a-6ea081fe11ec"), "740 Bryant River", "Staceybury", new DateTime(1954, 3, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "owensmadeline@le.info", "Jacqueline", "Female", "Delgado", "+1-260-098-8166x53321", "Utah" },
                    { new Guid("ddc629bb-8a4e-4fbd-8d34-b676cfe17d3f"), "32714 Carter Forks Suite 655", "West Caroline", new DateTime(1992, 10, 24, 0, 0, 0, 0, DateTimeKind.Unspecified), "brownfrancisco@hotmail.com", "Amy", "Male", "Murphy", "498-010-1975x57085", "Oklahoma" },
                    { new Guid("dfad2a0f-e518-4f66-b8bf-7622e24043a6"), "602 Kathleen Overpass Suite 099", "Greerbury", new DateTime(1995, 2, 28, 0, 0, 0, 0, DateTimeKind.Unspecified), "millerwilliam@bradley.biz", "Guy", "Female", "Rivera", "946-124-3020x915", "Minnesota" },
                    { new Guid("e01dab28-cf40-4ad4-b853-1d2610e6f284"), "42139 Garcia Light Apt. 451", "Hannahland", new DateTime(1984, 9, 6, 0, 0, 0, 0, DateTimeKind.Unspecified), "jcameron@yahoo.com", "Jim", "Female", "White", "+1-708-233-0157x5605", "North Dakota" },
                    { new Guid("ec1fbc50-9e01-422d-a0f4-81b6857da3fb"), "77155 Perez Ville Suite 859", "New Amanda", new DateTime(1959, 3, 6, 0, 0, 0, 0, DateTimeKind.Unspecified), "wallwalter@hayes.org", "Stephen", "Female", "Mckenzie", "7588362109", "Vermont" },
                    { new Guid("f98e3af7-4cfa-4992-a7d0-0b3f9dd438e8"), "4827 Shaffer Squares", "Paulaside", new DateTime(1963, 11, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "juliemcdonald@peterson-meyer.net", "Rachel", "Female", "Wells", "(243)658-8052x117", "California" },
                    { new Guid("f9c36008-a5bb-4d0f-88cf-28dfcda75e18"), "589 Abigail Landing Apt. 309", "Port Pamelamouth", new DateTime(1974, 10, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "wwashington@hotmail.com", "Kimberly", "Male", "Stevenson", "(641)102-2317", "Florida" },
                    { new Guid("fd9de59e-f08b-48c3-b755-1d725bc13bdb"), "76380 Mary Squares", "New David", new DateTime(1948, 1, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "sarahanderson@gonzales-wiley.com", "Suzanne", "Male", "Haley", "0794043354", "Hawaii" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Persons");
        }
    }
}
