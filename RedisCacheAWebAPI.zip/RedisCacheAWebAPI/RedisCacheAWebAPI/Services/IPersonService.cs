﻿using PersonManager.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonManager.Core.Services
{
    public interface IPersonService
    {
        public Task<List<Person>> PersonListAsync();

        public Task<Person> GetPersonDetailsByIdAsync(Guid personId);

        public Task<bool> AddPersonAsync(Person personDetails);

        public Task<bool> UpdatePersonAsync(Person personDetails);

        public Task<bool> DeletePersonAsync(Guid personId);
    }
}
