﻿using Microsoft.EntityFrameworkCore;
using PersonManager.Core.DatabaseContext;
using PersonManager.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonManager.Core.Services
{
    public class PersonService : IPersonService
    {
        private readonly ApplicationDBContext dbContextClass;

        public PersonService(ApplicationDBContext dbContextClass)
        {
            this.dbContextClass = dbContextClass;
        }

        public async Task<List<Person>> PersonListAsync()
        {
            return await dbContextClass.Persons.ToListAsync();
        }

        public async Task<Person> GetPersonDetailsByIdAsync(Guid personId)
        {
            return await dbContextClass.Persons.Where(ele => ele.Id == personId).FirstOrDefaultAsync();
        }

        public async Task<bool> AddPersonAsync(Person personDetails)
        {
            await dbContextClass.Persons.AddAsync(personDetails);
            var result = await dbContextClass.SaveChangesAsync();
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<bool> UpdatePersonAsync(Person personDetails)
        {
            var isProduct = PersonDetailsExists(personDetails.Id);
            if (isProduct)
            {
                dbContextClass.Persons.Update(personDetails);
                var result = await dbContextClass.SaveChangesAsync();
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        public async Task<bool> DeletePersonAsync(Guid personId)
        {
            var findProductData = dbContextClass.Persons.Where(_ => _.Id == personId).FirstOrDefault();
            if (findProductData != null)
            {
                dbContextClass.Persons.Remove(findProductData);
                var result = await dbContextClass.SaveChangesAsync();
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        private bool PersonDetailsExists(Guid personId)
        {
            return dbContextClass.Persons.Any(e => e.Id == personId);
        }
    }
}
