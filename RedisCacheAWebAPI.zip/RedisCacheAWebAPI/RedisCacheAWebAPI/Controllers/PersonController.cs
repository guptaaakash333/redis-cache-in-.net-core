using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using PersonManager.Core.DatabaseContext;
using PersonManager.Core.Entities;
using PersonManager.Core.Services;
using RedisCacheDemo.Repositories.AzureRadisCache;
using System.Collections.Generic;

namespace RedisCacheAWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PersonController : ControllerBase
    {
       
        private readonly ILogger<PersonController> _logger;
        private readonly ApplicationDBContext _context;    private readonly IRedisCache _cache;
        private readonly IPersonService _personService;


        public PersonController(ILogger<PersonController> logger, ApplicationDBContext context, IRedisCache cache, IPersonService personService)
        {
            _logger = logger;
            _context = context;
            _cache=cache;
            _personService = personService;
        }

        //Get Persons List
        [HttpGet]
        public async Task<ActionResult<List<Person>>> GetPersons()
        {
            var cacheData = _cache.GetCacheData<List<Person>>("person");
            if (cacheData != null)
            {
                return new List<Person>(cacheData);
            }

            var personList = await _personService.PersonListAsync();
            if (personList != null)
            {
                var expirationTime = DateTimeOffset.Now.AddMinutes(1.0);
                _cache.SetCacheData<List<Person>>("person", personList, expirationTime);
                return Ok(personList);
            }
            else
            {
                return NoContent();
            }
        }

        //GetPerson details by Id
        [HttpGet("{personId}")]
        public async Task<ActionResult<Person>> GetPersonDetailsByAsync(Guid personId)
        {
            var cacheData = _cache.GetCacheData<List<Person>>("person");
            if (cacheData != null)
            {
                Person filteredData = cacheData.Where(x => x.Id == personId).FirstOrDefault();
                return new ActionResult<Person>(filteredData);
            }

            var personDetails = await _personService.GetPersonDetailsByIdAsync(personId);
            if (personDetails != null)
            {
                return Ok(personDetails);
            }
            else
            {
                return NotFound();
            }
        }

        //Add person
        [HttpPost]
        public async Task<IActionResult> AddPersonAsync(Person person)
        {
            var isPersonInserted = await _personService.AddPersonAsync(person);
            _cache.RemoveData("person");
            if (isPersonInserted)
            {
                return Ok(isPersonInserted);
            }
            else
            {
                return BadRequest();
            }
        }

        //Update person
        [HttpPut]
        public async Task<IActionResult> UpdatePersonAsync(Person person)
        {
            var isPersonUpdated = await _personService.UpdatePersonAsync(person);
            _cache.RemoveData("person");
            if (isPersonUpdated)
            {
                return Ok(isPersonUpdated);
            }
            else
            {
                return BadRequest();
            }
        }

        //Delete person 
        [HttpDelete]
        public async Task<IActionResult> DeletePersonAsync(Guid personId)
        {
            var isPersonDeleted = await _personService.DeletePersonAsync(personId);
            _cache.RemoveData("person");
            if (isPersonDeleted)
            {
                return Ok(isPersonDeleted);
            }
            else
            {
                return BadRequest();
            }
        }

    }
}
